// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass

export default class OffOn extends cc.Component {

    @property(cc.Node)
    nodeList: cc.Node[] = [null];

    // onLoad () {}

    offOn () {
        for (let i = 0; i < this.nodeList.length; i++) {
            this.nodeList[i].active = false;            
        };

        for (let i = 0; i < this.nodeList.length; i++) {
            this.nodeList[i].active = true;            
        };
    }

    offOnly () {
        for (let i = 0; i < this.nodeList.length; i++) {
            this.nodeList[i].active = false;            
        };
    }

    
}
